# 💣 BOMBER VAMPIRE — Game Design Document

> **Gênero:** Action / Roguelite / Survivor  
> **Plataforma:** Web (HTML5 Canvas)  
> **Controles:** Teclado  
> **Engine:** Vanilla JavaScript  
> **Estilo Visual:** Pixel Art / Retro

---

## 📋 Conceito

**Bomber Vampire** combina a mecânica de colocação de bombas do *Bomberman* com o sistema de hordas e progressão do *Vampire Survivors*. O jogador se move livremente por uma arena enquanto coloca bombas estrategicamente para eliminar ondas cada vez maiores de inimigos. Ao matar inimigos, gems de XP são dropadas e coletadas para subir de nível, desbloqueando perks poderosos que transformam a gameplay a cada partida.

---

## 🎮 Controles

| Ação | Tecla |
|---|---|
| Mover | `WASD` ou `Setas` |
| Colocar bomba | `Space` (durante gameplay) |
| Navegar upgrades | `← →` ou `A / D` |
| Confirmar menu / upgrade | **Segurar** `Space` ou `Enter` (~0.5s) |

> O sistema de **Hold to Confirm** exige segurar a tecla por meio segundo, com uma barra de progresso visual. Isso evita confirmações acidentais, especialmente ao trocar entre gameplay e menus.

---

## 🧑‍🎮 O Jogador

O jogador é representado como um personagem estilo Bomberman com animação de caminhada em 4 direções.

### Stats Base

| Atributo | Valor Inicial |
|---|---|
| HP | 5 |
| Velocidade | 3.2 |
| Bombas simultâneas | 1 |
| Alcance da explosão | 2 tiles |
| Cooldown entre bombas | 90 frames (~1.5s) |
| Tempo do pavio (fuse) | 120 frames (2s) |
| Forma da explosão | Cruz (+) |
| Alcance do magneto (XP) | 3 tiles |

### Mecânicas do Jogador

- **Movimento livre** — O jogador se move em pixel, não preso ao grid
- **Invencibilidade temporária** — Ao tomar dano, ganha 60 frames (~1s) de invencibilidade com flash visual
- **Dano por contato** — Inimigos causam dano ao encostar no jogador
- **Auto-dano** — As próprias bombas podem ferir o jogador (⚠️!)

---

## 💣 Sistema de Bombas

### Colocação
- O jogador coloca bombas na tile do grid correspondente à sua posição
- Não é possível colocar duas bombas na mesma tile
- Existe um cooldown entre colocações, controlado por `bombCooldownMax`

### Detonação
- Cada bomba tem um timer (pavio) que conta regressivamente
- Ao chegar a zero, a bomba explode na forma configurada
- A bomba pulsa visualmente e fica vermelha nos últimos 25% do timer
- Um anel de timer ao redor da bomba mostra o tempo restante

### Preview de Explosão
- Após a bomba ser colocada, um overlay mostra as tiles que serão atingidas
- A cor vai de laranja para vermelho conforme o timer diminui
- A opacidade e velocidade de pulsação aumentam com a urgência
- O preview respeita a **forma** atual da explosão

### Formas de Explosão

| Forma | Padrão | Obtida via |
|---|---|---|
| **Cruz** (+) | Linhas retas nas 4 direções cardeais | Padrão inicial |
| **Circular** (⭕) | Área redonda ao redor do centro | Perk "Bomba Circular" |
| **X** (✖) | Diagonais em 4 direções | Perk "Bomba X" |
| **Estrela** (⭐) | Cruz + X combinados (8 direções) | Perk "Bomba Estrela" |
| **Linha** (➖) | Linhas completas horizontal + vertical | Perk "Bomba Linha" |
| **Total** (🟥) | Quadrado completo no alcance | Perk "Bomba Total" |

---

## 👾 Inimigos

Todos os inimigos se movem no **grid** (tile a tile) em direção ao jogador, com interpolação suave entre as tiles.

### Tipos

| Inimigo | HP | XP | Velocidade | Aparece em | Sprite |
|---|---|---|---|---|---|
| 🟢 **Slime** | 1 | 1 | Lento | 0:00 | Blob verde pulsante |
| 🟣 **Bat** | 1 | 1 | Rápido | 0:30 | Morcego com asas batendo |
| ⬜ **Skeleton** | 2 | 2 | Médio | 1:00 | Caveira com corpo |
| 🔵 **Ghost** | 3 | 3 | Rápido | 2:00 | Fantasma translúcido flutuante |
| 🔴 **Demon** | 5 | 5 | Lento | 3:00 | Grande com chifres |

### Comportamento
- Movem-se em grid com `moveDelay` variável (quanto menor, mais rápido)
- Escolhem mover-se no eixo com maior distância até o jogador
- Spawnam nas bordas da tela visível

### Efeitos de Status
- **Congelado** (🧊) — Paralisa o inimigo por 2 segundos. Visual: borda azul brilhante
- **Queimando** (🔥) — Causa dano por segundo durante 3 segundos. Visual: aura laranja piscante

---

## 💎 Sistema de XP e Level Up

### Gems
- Inimigos derrotados dropam gems de XP (diamantes azuis flutuantes)
- Gems duram **30 segundos** antes de desaparecer (fading nos últimos segundos)
- Gems são **atraídas magneticamente** ao jogador dentro do `magnetRange`
- Gems saem voando ao spawnar e desaceleram

### Level Up
- XP necessário escala: `xpNeeded = floor(anterior * 1.4) + 2`
- Começa precisando de 5 XP
- Ao subir de nível, o jogo pausa e mostra 3 (ou 4 com Jackpot) opções de perk
- O jogador navega com setas e confirma segurando Space

---

## ⬆️ Sistema de Perks (36 Total)

### 💣 Perks de Bomba

| Perk | Efeito |
|---|---|
| +1 BOMBA | +1 bomba simultânea |
| +1 ALCANCE | +1 tile de alcance |
| -COOLDOWN | -12 frames de cooldown (mín 15) |
| PAVIO CURTO | Bombas explodem 20 frames mais rápido (mín 40) |
| MEGA BOMBA | +2 alcance, +20 cooldown |
| BOMBA VELOZ | +1 bomba, -8 cooldown |
| REAÇÃO EM CADEIA | Bombas detonam outras bombas no alcance |
| EXPLOSÃO PERFURANTE | +1 dano por explosão |

### 🔄 Perks de Forma

| Perk | Efeito |
|---|---|
| BOMBA CIRCULAR | Explosão em área circular |
| BOMBA X | Explosão em diagonal (X) |
| BOMBA ESTRELA | Cruz + X combinados |
| BOMBA LINHA | Linhas completas H + V |
| BOMBA TOTAL | Quadrado completo |

### 🧑 Perks do Player

| Perk | Efeito |
|---|---|
| +VELOCIDADE | +0.5 velocidade |
| +1 HP MAX | +1 HP máximo (cura total) |
| CURA | Restaura toda a vida |
| ARMADURA | Reduz 1 de dano recebido |
| ESCUDO | Bloqueia o próximo hit completamente |
| REGENERAÇÃO | +1 HP a cada 10 segundos |
| DASH | +1.0 velocidade |
| TANQUE | +3 HP max, -0.5 velocidade |
| FANTASMA | 3s invencível após dano |

### 💎 Perks de XP e Loot

| Perk | Efeito |
|---|---|
| MAGNETISMO | +2 tiles de alcance magnético |
| XP DUPLO | +50% XP por gem |
| SORTE | Chance de gems extras ao matar |
| VÁCUO | Puxa todas as gems da tela + magneto +1 |
| TESOURO | Gems valem o dobro |

### ⚔️ Perks de Combate

| Perk | Efeito |
|---|---|
| ESPINHOS | Reflete 1 dano no contato |
| CONGELAR | 30% chance de congelar inimigos (2s) |
| QUEIMAR | Explosões queimam (1 dano/s por 3s) |
| CRÍTICO | 20% chance de dano dobrado |
| BOMBA AO MATAR | Mini explosão ao matar inimigo |
| AURA DE MEDO | Inimigos próximos ficam lentos |
| TEMPESTADE | Raio aleatório a cada 5s |
| EXECUÇÃO | Mata inimigos com <20% HP automaticamente |
| INVENCÍVEL | 5s invencível ao subir de nível |
| JACKPOT | +1 opção de perk no próximo level up |

---

## 🌊 Sistema de Ondas

- Inimigos spawnam continuamente na borda da tela
- A taxa de spawn aumenta com o tempo: `spawnRate = max(10, 90 - floor(minutos * 8))`
- O número de inimigos por spawn escala: `1 + floor(minutos * 0.5)`
- Novos tipos de inimigos aparecem progressivamente (Slime → Bat → Skeleton → Ghost → Demon)
- Não há fim — o objetivo é sobreviver o máximo possível

---

## 🏆 High Score

- **Score** = `(segundos_sobrevividos × 10) + (kills × 5) + (nível × 20)`
- Salvo em `localStorage` e persiste entre sessões
- Exibido na tela de Start (se existir) e Game Over
- Indica "NEW!" quando o recorde é batido

---

## 🖥️ Interface (HUD)

### Durante o Jogo
- **Canto superior esquerdo:** HP bar + contagem de bombas disponíveis + barra de cooldown
- **Centro superior:** Timer (MM:SS) + barra de XP + nível atual
- **Canto superior direito:** Contador de kills

### Tela de Start
- Título do jogo + instruções de controle
- High Score (se existir)
- Barra de Hold Space para iniciar

### Tela de Level Up
- Overlay escuro (85% opacidade)
- Cards de upgrade com ícone, nome e descrição
- Card selecionado com borda dourada e elevação
- Barra de Hold Space para confirmar
- Navegação com setas

### Tela de Game Over
- Stats finais: tempo, kills, nível
- High Score (com indicador "NEW!")
- Barra de Hold Space para recomeçar

---

## 🎨 Estilo Visual

### Geral
- **Fonte:** Press Start 2P (Google Fonts) — estética retro/pixel
- **Paleta:** Tons escuros com elementos vibrantes (explosões laranjas, gems azuis, UI dourada)

### Arena
- Piso de dungeon em xadrez (dois tons de marrom/cinza escuro)
- Rachaduras e detalhes aleatórios nas tiles para textura
- Borda vermelha semitransparente delimitando o mapa
- Mapa: 40×30 tiles de 48px = 1920×1440 pixels

### Efeitos Visuais
| Efeito | Descrição |
|---|---|
| **Screen shake** | Tremor de câmera ao explodir bombas e tomar dano |
| **Damage flash** | Flash vermelho na tela ao tomar dano |
| **Partículas** | Explosões coloridas em kills, coleta de gems, cura |
| **Damage numbers** | Números flutuando para cima com fade out |
| **Pulsação de bomba** | Bomba cresce/encolhe antes de explodir |
| **Faísca do pavio** | Partícula amarela/vermelha na ponta da bomba |
| **Preview de explosão** | Overlay no grid mostrando área de impacto |
| **Gems flutuantes** | Diamantes azuis brilhantes com bob up/down |

### Câmera
- Segue o jogador com centralização
- Screen shake com offset aleatório proporcional à intensidade

---

## ⚙️ Especificações Técnicas

| Item | Valor |
|---|---|
| **Tile size** | 48px |
| **Mapa** | 40 × 30 tiles (1920 × 1440 px) |
| **FPS alvo** | 60 (requestAnimationFrame) |
| **Renderização** | Canvas 2D Context |
| **Persistência** | localStorage (high score) |
| **Arquivo único** | index.html (HTML + CSS + JS inline) |

---

## 🔮 Possíveis Expansões Futuras

- Sons e música
- Mais tipos de inimigos (boss waves)
- Itens passivos drops no mapa
- Multiplicador de dificuldade
- Árvore de evolução de perks
- Skins para o jogador
- Leaderboard online
- Power-ups temporários no mapa
- Obstáculos destrutíveis no grid
